from __future__ import annotations

import hashlib
import hmac
import json
import time
import unittest
from urllib.parse import urlencode

from app import auth
from app.config import Settings


class TelegramInitDataTests(unittest.TestCase):
    def setUp(self) -> None:
        self.original_settings = auth.settings
        auth.settings = Settings(
            bot_token="123456:test-token",
            webapp_url="https://example.test",
            database_url="sqlite:///./test.db",
            allowed_telegram_ids=frozenset({42}),
            mini_app_auth_max_age=3600,
            dev_mode=False,
        )

    def tearDown(self) -> None:
        auth.settings = self.original_settings

    def signed_data(self, user_id: int = 42, auth_date: int | None = None) -> str:
        values = {
            "auth_date": str(auth_date or int(time.time())),
            "query_id": "test-query",
            "user": json.dumps({"id": user_id, "first_name": "Иван", "username": "ivan"}),
        }
        data_check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
        secret = hmac.new(b"WebAppData", auth.settings.bot_token.encode(), hashlib.sha256).digest()
        values["hash"] = hmac.new(secret, data_check_string.encode(), hashlib.sha256).hexdigest()
        return urlencode(values)

    def test_accepts_valid_telegram_data(self) -> None:
        user = auth.validate_init_data(self.signed_data())
        self.assertEqual(user.telegram_id, 42)
        self.assertEqual(user.name, "Иван")

    def test_rejects_tampered_data(self) -> None:
        with self.assertRaises(ValueError):
            auth.validate_init_data(self.signed_data() + "tampered")

    def test_rejects_user_outside_allow_list(self) -> None:
        with self.assertRaises(PermissionError):
            auth.validate_init_data(self.signed_data(user_id=99))

    def test_rejects_expired_data(self) -> None:
        with self.assertRaises(ValueError):
            auth.validate_init_data(self.signed_data(auth_date=int(time.time()) - 3601))


if __name__ == "__main__":
    unittest.main()

